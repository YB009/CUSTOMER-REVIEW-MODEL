SAMPLE_REVIEWS = [
    "The product quality is excellent and the service was great.",
    "I'm very disappointed with the customer service and product durability.",
    "Amazing experience! The staff was friendly and helpful.",
    "The product arrived damaged and the return process was complicated.",
    "Great value for money, would definitely recommend.",
    "Poor quality materials and not worth the price.",
    "Excellent customer support and fast shipping.",
    "The product didn't meet my expectations at all.",
    "Very satisfied with the purchase and delivery.",
    "Terrible experience, would not buy again."
]